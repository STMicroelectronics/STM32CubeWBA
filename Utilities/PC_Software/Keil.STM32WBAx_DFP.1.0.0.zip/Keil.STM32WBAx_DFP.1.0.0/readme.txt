/**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WBAx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32WBAx 
  devices by MDK-ARM v5.25 and laters.

  Running the "Keil.STM32WBAx_DFP.1.0.0.pack" adds the following:
  ==============================================================
  
  1. Part numbers for  :
   - Part numbers with 1MB Flash size :STM32WBA50xGxx/52xGxx/54xGxx/55xGxx
   - Part numbers with 512KB Flash size :STM32WBA50xExx/52xExx/54xExx/55xExx
   
  2. Automatic STM32WBA flash algorithm selection 

  3. SVD file for STM32WBA52


  How to use:
  ==========
  * Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
  You can download pack from keil web site @ www.keil.com
 
  * Double Clic on  "Keil.STM32WBAx_DFP.1.0.0.pack" in order to install this pack in the Keil install 
  directory.

