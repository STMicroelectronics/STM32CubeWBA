/**
  *************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WBA5x devices support on EWARM.
  *************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************/
  These packages contains the needed files to be installed in order to support STM32WBA5x 
  devices by EWARM9 and laters.

  We inform you that this package is suitable for internal use only.
  

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  =========================================================================================================== 
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
		- Part numbers with 1MB Flash size   : STM32WBA54xG/WBA55xG/WBA52xG/WBA50xG/WBA5MxG.
		- Part numbers with 512KB Flash size : STM32WBA54xE/WBA55xE/WBA52xE/WBA50xE.
   
		- Automatic STM32WBA flash algorithm selection 
  
    3. The following SVD files will be added:
    - STM32WBA52 SVD file v1r2
	- STM32WBA55,STM32WBA54 & STM32WBA50 SVD file v0r3.

PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
    That you can run EWARMv9_STM32WBAx_V1.4.0.exe only if the uninstall is not needed.

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.50.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32WBAx_V1.4.0.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   


 SVD files ReleaseNotes:
 =======================
	=======================================================
	STM32WBA55_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Renamed from STM32WBAxx:
	Complete support (from IPxact)
	=======================================================
	STM32WBA55_v0r2:
	=======================================================
	Derived from STM32WBA52_v1r1
	Doc ID:  RM0493 Rev 3 - October 2023
	Adding support for COMP1/COMP2
	========================================================
	STM32WBA55_v0r3:
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
	Adding support for PTACONV
	
	
	
	=======================================================
	STM32WBA54_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Renamed from STM32WBAxx:
	Complete support (from IPxact)
	=======================================================
	STM32WBA54_v0r2:
	=======================================================
	Derived from STM32WBA52_v1r1
	Doc ID:  RM0493 Rev 3 - October 2023
	Adding support for COMP1/COMP2
	========================================================
	STM32WBA54_v0r3:
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
	Adding support for PTACONV
	
	
	=======================================================
	STM32WBA52_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 1 _ 5 January 2022 
	Renamed from STM32WBAxx_v0r3: 
	Complete support (from IPxact)
	=======================================================
	STM32WBA52_v1r0: official release
	=======================================================
	Doc ID:  RM0493 Rev 3 _ October 2023 
	=======================================================
	STM32WBA52_v1r1: 
	=======================================================
	Doc ID:  RM0493 Rev 3 _ October 2023 
	w/o support COMP1/COMP2/SAI1
	========================================================
	STM32WBA52_v1r2: 
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
		
		
	=======================================================
	STM32WBA50_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Complete support (from IPxact)
	=======================================================
	STM32WBA50_v0r2: 
	=======================================================
	Derived from STM32WBA52_v1r1
	Doc ID:  RM0493 Rev 3 - October 2023
	Deleting support for secure access & Disable condition (Marketing decision)
	w/o SAES/COMP1/COMP2/GTZC/I2C1/LPTIM2/SPI1/TIM3/TIM17/USART2	
	========================================================
	STM32WBA50_v0r3: 
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers








	



