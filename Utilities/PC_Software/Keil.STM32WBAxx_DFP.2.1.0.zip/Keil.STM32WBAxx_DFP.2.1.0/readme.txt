/**
  ******************************************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WBAxx devices support on MDK-ARM.
  ******************************************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *****************************************************************************************************************************/

  Package general purpose:
  ==========================================================================================================================================
	These packages contains the needed files to be installed in order to support STM32WBAxx devices by MDK-ARM v5.25 and laters.

	We inform you that this package is suitable for internal & external use.
  
   Running the "Keil.STM32WBAxx_DFP.2.1.0.pack" adds the following:
   =========================================================================================================================================
   1. Part numbers for  :
        - Product Number with 2MB Flash size: STM32WBA62xIxx/WBA63xIxx/WBA64xIxx/WBA65xIxx/WBA6MxIxx.
        - Product Number with 1MB Flash size: STM32WBA50xGxx/WBA52xGxx/WBA54xGxx/WBA55xGxx/WBA5MxGxx STM32WBA62xG/WBA63xG/WBA64xG/WBA65xG
        - Product Number with 512 kB Flash size: STM32WBA50xExx/STM32WBA52xExx/STM32WBA54xExx/STM32WBA55xExx

        - Automatic STM32WBAxx internal flash algorithm selection   
   
   2. The following SVD files: 
        - STM32WBA55, STM32WBA54, STM32WBA50, STM32WBA65 & STM32WBA6M v1r0 SVD file.   
		- STM32WBA64, STM32WBA63 & STM32WBA62 v1r1 SVD file.   
		- STM32WBA52 v1r3 SVD file. 

   How to use:
   =========================================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
 
	* Double Clic on  "Keil.STM32WBAxx_DFP.2.1.0.pack" in order to install this pack in 
	  the Keil install directory.
	
	PS: Please make sure that you are using PackUnzip.exe to run this pack.

   SVD files ReleaseNotes:
   =========================================================================================================================================
		=======================================================
		STM32WBA5_v1r0
		=======================================================
		V1.0   First release
		
		=======================================================
		STM32WBA6_v1r1
		=======================================================
		V1.0   First release
		V1.1   Adding support for STM32WBA6M and update in GPIOG