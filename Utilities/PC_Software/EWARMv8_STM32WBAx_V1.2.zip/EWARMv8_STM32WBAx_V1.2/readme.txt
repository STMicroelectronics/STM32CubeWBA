**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WBAx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32WBAx 
  devices by EWARM8 and laters.

  1. If you have already installed an STM32WBAx patch before, you can remove it by running 
  Uninstall_Patch.bat (run as administrator).

  2. Running the "EWARMv8_STM32WBAx_V1.2.exe" SIGNED adds the following:
   ==========================================================================
  
   - Part numbers with 1MB Flash size   : STM32WBA54xG/WBA55xG/WBA52xG/WBA50xG
   - Part numbers with 512KB Flash size : STM32WBA54xE/WBA55xE/WBA52xG/WBA50xE
   
   - Automatic STM32WBA flash algorithm selection 
   - STM32WBA52 SVD file 


 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
 You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32WBAx_V1.2.exe"  as administrator on EWARM install directory.
 Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \". 






	



